var SizeScale = 1740
var DistanceScale = 3000000


var Sol = {
    Distance: 0,
    Diameter: 10,
    x: Layout_Width/2,
    y: Layout_Height/2,

    Update: function(){
        DrawArc(this.x, this.y, this.Diameter/2, 0, Math.PI*2, 1, 'rgb(255, 199, 74)', 'fill')
    }
}

var Mercurio = {
    Distance: 57910000, //medido em KM
    Diameter: 4879,
    x: 0,
    y: 0,
    ang: 0, //angulo que ira ser incrementado
    color: 'rgb(151, 151, 159)',
}

var Venus = {
    Distance: 108200000,
    Diameter: 12104,
    x: 0,
    y: 0,
    ang: 0,
    color: 'rgb(187, 183, 171)',
}

var Terra = {
    Distance: 149600000,
    Diameter: 12756,
    x: 0,
     y: 0,
    ang: 0,
    color: 'rgb(140, 177, 222)',
}

var Marte = {
    Distance: 227940000,
    Diameter: 6794,
    x: 0,
    y: 0,
    ang: 0,
    color: 'rgb(226, 123, 88)',
}
var Jupiter = {
    Distance: 778330000,
    Diameter: 142984,
    x: 0,
    y: 0,
    ang: 0,
    color: 'rgb(210, 207, 218)',
}
var Saturno = {
    Distance: 1429400000,
    Diameter: 120536,
    x: 0,
    y: 0,
    ang: 0,
    color: 'rgb(197, 171, 110)',
}

var Lua = {
    Distance: 19840400,
    Diameter: 3840,
    x: 0,
    y: 0,
    ang: 0,
    color: 'rgb(148, 144, 141)',
}

var _IO = {
    Distance: 159840400,
    Diameter: 3630,
    x: 0,
    y: 0,
    ang: 0,
    color: 'gray',
}
var Calisto = {
    Distance: 169840400,
    Diameter: 4800,
    x: 0,
    y: 0,
    ang: 0,
    color: 'gray',
}

var Europa = {
    Distance: 189840400,
    Diameter: 5262,
    x: 0,
    y: 0,
    ang: 0,
    color: 'gray',
}