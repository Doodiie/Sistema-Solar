//             _______  _______  __    _  _______  ___   __    _  _______ 
//            |       ||   _   ||  |  | ||       ||   | |  |  | ||       |
//            |       ||  |_|  ||   |_| ||    ___||   | |   |_| ||    ___|
//            |       ||       ||       ||   | __ |   | |       ||   |___ 
//            |      _||       ||  _    ||   ||  ||   | |  _    ||    ___|
//            |     |_ |   _   || | |   ||   |_| ||   | | | |   ||   |___ 
//            |_______||__| |__||_|  |__||_______||___| |_|  |__||_______|
// --Arquivo individual com funções para facilitar a criação dos projetos

var ProjectName = "SolarSystem"
var Layout_Width = 1000 //alterar tbm no style
var Layout_Height = 950
var BackgroundColor = 'rgb(25, 29, 30)'
var ClearBackground = true

//***don't change anything down here********
canvas = document.createElement('canvas')
canvas.width =  Layout_Width
canvas.height = Layout_Height

canvas.style.border = '2px solid rgb(58, 78, 118)'
canvas.style.boxShadow = "2px 2px 12px rgb(58, 78, 118, 0.5)"
canvas.style.position = 'absolute'
canvas.style.top = '50%'
canvas.style.left = '50%'
canvas.style.transform = 'translate(-50%, -50%)'
document.body.appendChild(canvas)
ctx = canvas.getContext('2d')
document.title = ProjectName

function Draw(){
    if(ClearBackground){
        ctx.clearRect(0, 0, Layout_Width, Layout_Height)
        ctx.fillStyle = BackgroundColor
        ctx.fillRect(0, 0, Layout_Width, Layout_Height)
    }

  
    requestAnimationFrame(Draw)

}

requestAnimationFrame(Draw)

function Random(min, max)  {return Math.random()*(max - min) + min}

function intRandom(min, max)  {
    return Math.floor(Math.random()*(max+1 - min) + min)
}

var DrawRect = function(elm) {
    ctx.fillStyle = elm.color
    ctx.fillRect(elm.x, elm.y, elm.w, elm.h)
}
var DrawRectnoElm = function(x, y, w, h, color) {
    ctx.fillStyle = color
    ctx.fillRect(x, y, w, h)
}
var DrawArc = function(x, y, radius, start, end, anticlockwise, color, type) {
    ctx.beginPath();
    ctx.fillStyle = color
    ctx.strokeStyle = color
    ctx.arc(x, y, radius, start, end, anticlockwise);
    ctx.lineWidth = 1
    if (type === 'fill') {
        ctx.fill()
    } else {
        ctx.stroke();
    }
    
}

var DrawText = function(Text, x, y, fonts, color) {
    this.Text = Text
    this.x = x
    this.y = y
    this.fonts = fonts
    this.color = color 

    ctx.font = fonts //'bold 48px serif';
    ctx.fillStyle = color
    ctx.fillText(this.Text, this.x, this.y);
}


var DrawLine = function(Xi, Yi, Xf, Yf, color, size) {

    ctx.beginPath();

    ctx.moveTo(Xi, Yi);
    ctx.strokeStyle = color
    ctx.lineTo(Xf, Yf);
    ctx.lineWidth = size
    ctx.stroke();

    ctx.closePath()

}

var Distance = function(x1, y1, x2, y2) {
    var D = Math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
    return parseInt(D)
}

var collision = function(A, B) {
    if (A.x >= B.x - A.w && A.x <= B.x + B.w && A.y >= B.y - A.h && A.y <= B.y + B.h) {
        return true
    } else {
        return false
    }
}
var collisionNoElm = function(AX, AY, AW, AH, BX, BY, BW, BH) {
    if (AX >= BX - AW && AX <= BX + BW && AY >= BY - AH && AY <= BY + BH) {
        return true
    } else {
        return false
    }
}

var Cos = function(ang){
    return Math.cos(ang * Math.PI/180)
}
var Sen = function(ang){
    return Math.sin(ang * Math.PI/180)
}

function behavior_solid(r1, r2){

    var halfWidth_r1 = r1.w/2
    var halfHeigh_r1 = r1.h/2
    var centerX_r1 = r1.x + halfWidth_r1;
    var centerY_r1 = r1.y + halfHeigh_r1;

    var halfWidth_r2 = r2.w/2
    var halfHeigh_r2 = r2.h/2
    var centerX_r2 = r2.x + halfWidth_r2;
    var centerY_r2 = r2.y + halfHeigh_r2;

    //catetos//
    var catX = centerX_r1 - centerX_r2;
    var catY = centerY_r1 - centerY_r2;

    //soma das metades
    var sumHalfWidth = halfWidth_r1 + halfWidth_r2;
    var sumHalfHeight = halfHeigh_r1 + halfHeigh_r2;

    if(Math.abs(catX) < sumHalfWidth && Math.abs(catY) < sumHalfHeight){

        var overlapX = sumHalfWidth - Math.abs(catX);
        var overlapY = sumHalfHeight - Math.abs(catY);

        if(overlapX >= overlapY){                                             //colisão por cima ou por baixo
            if(catY > 0){                                                     
                r1.y += overlapY;
            } else {
                r1.y -= overlapY;
            }
        } else {                                                              //colisão pela esquerda ou direita
            if(catX > 0){
                r1.x += overlapX;

            } else {

                r1.x -= overlapX;
            }
        }
    }
}

//****KEYS*****************************************************************/
var onPressedKey = []
document.addEventListener("keydown", function (e) {
    onPressedKey[e.key] = true;
});
document.addEventListener("keyup", function (e) {
    onPressedKey[e.key] = false;
});
//*************************************************************************/

var _8Direction = function(elm){

    if(onPressedKey['w']) elm.y -= elm.speed
    if(onPressedKey['s']) elm.y += elm.speed
    if(onPressedKey['a']) elm.x -= elm.speed
    if(onPressedKey['d']) elm.x += elm.speed

}

var _4Direction = function(elm){

     switch (true) {
        case onPressedKey['w']: elm.y -= elm.speed; break; 
        case onPressedKey['a']: elm.x -= elm.speed; break;
        case onPressedKey['s']: elm.y += elm.speed; break;
        case onPressedKey['d']: elm.x += elm.speed; break;
           
    }
}