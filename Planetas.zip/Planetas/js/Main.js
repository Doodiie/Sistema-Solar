function GameLoop(){ 
    
    Sol.Update()
    
    Translation(Mercurio, Sol, Mercurio.Distance)
    Translation(Venus, Sol, Venus.Distance)
    Translation(Terra, Sol, Terra.Distance)
    Translation(Marte, Sol, Marte.Distance)
    Translation(Jupiter, Sol, Jupiter.Distance)
    Translation(Saturno, Sol, Saturno.Distance)

    Translation(Lua, Terra, Lua.Distance)

    Translation(_IO, Jupiter, _IO.Distance)
    Translation(Calisto, Jupiter, Calisto.Distance)
    Translation(Europa, Jupiter, Europa.Distance)


    requestAnimationFrame(GameLoop)
}

function Translation(A, B, distance){ //A planeta a girar, B centro e distance distancia ao centro

    A.x = B.x + (distance - A.Diameter/2)/DistanceScale*Cos(A.ang)
    A.y = B.y - (distance - A.Diameter/2)/DistanceScale*Sen(A.ang)
    A.ang += 70/((distance - A.Diameter/2)/DistanceScale) //angulo será incrementado baseado na distancia ao centro
    
    if(A.ang >= 360) A.ang //retornar o valor pra 0 após girar completamente

    DrawArc(B.x, B.y, (distance - A.Diameter/2)/DistanceScale, 0, Math.PI*2, 1, 'rgba(255,255,255,0.05)', 'stroke') //desenha o caminho
    DrawArc(A.x, A.y, (A.Diameter/SizeScale)/2, 0, Math.PI*2, 1, A.color, 'fill') //desenha o planeta
}


requestAnimationFrame(GameLoop)
